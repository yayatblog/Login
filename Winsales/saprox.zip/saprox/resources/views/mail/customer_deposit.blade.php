<h1>Hey {{$name}}!</h1>
<h3>{{$amount}} {{$general_setting->currency}} has successfully recharged in your account.</h3>
<p>Your current balance is: {{$balance}}</p>
<p>Thank you</p>